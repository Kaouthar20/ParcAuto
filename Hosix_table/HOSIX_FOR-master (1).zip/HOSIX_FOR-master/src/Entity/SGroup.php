<?php

namespace App\Entity;

use App\Repository\SGroupRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: SGroupRepository::class)]
class SGroup
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column(type: 'integer')]
    private $id;

    #[ORM\ManyToOne(targetEntity: SFamililas::class, inversedBy: 'sGroups')]
    private $family;

    #[ORM\Column(type: 'integer')]
    private $grouper;

    #[ORM\Column(type: 'string', length: 255)]
    private $nom;

    #[ORM\Column(type: 'string', length: 255)]
    private $userModify;

    #[ORM\Column(type: 'datetime')]
    private $dateModify;

    #[ORM\Column(type: 'integer')]
    private $active;

    #[ORM\OneToMany(mappedBy: 'grouper', targetEntity: SArticle::class)]
    private $sArticles;

    public function __construct()
    {
        $this->sArticles = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getFamily(): ?SFamililas
    {
        return $this->family;
    }

    public function setFamily(?SFamililas $family): self
    {
        $this->family = $family;

        return $this;
    }

    public function getGrouper(): ?int
    {
        return $this->grouper;
    }

    public function setGrouper(int $grouper): self
    {
        $this->grouper = $grouper;

        return $this;
    }

    public function getNom(): ?string
    {
        return $this->nom;
    }

    public function setNom(string $nom): self
    {
        $this->nom = $nom;

        return $this;
    }

    public function getUserModify(): ?string
    {
        return $this->userModify;
    }

    public function setUserModify(string $userModify): self
    {
        $this->userModify = $userModify;

        return $this;
    }

    public function getDateModify(): ?\DateTimeInterface
    {
        return $this->dateModify;
    }

    public function setDateModify(\DateTimeInterface $dateModify): self
    {
        $this->dateModify = $dateModify;

        return $this;
    }

    public function getActive(): ?int
    {
        return $this->active;
    }

    public function setActive(int $active): self
    {
        $this->active = $active;

        return $this;
    }

    /**
     * @return Collection|SArticle[]
     */
    public function getSArticles(): Collection
    {
        return $this->sArticles;
    }

    public function addSArticle(SArticle $sArticle): self
    {
        if (!$this->sArticles->contains($sArticle)) {
            $this->sArticles[] = $sArticle;
            $sArticle->setGrouper($this);
        }

        return $this;
    }

    public function removeSArticle(SArticle $sArticle): self
    {
        if ($this->sArticles->removeElement($sArticle)) {
            // set the owning side to null (unless already changed)
            if ($sArticle->getGrouper() === $this) {
                $sArticle->setGrouper(null);
            }
        }

        return $this;
    }
}
