<?php

namespace App\Entity;

use App\Repository\SFamililasRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: SFamililasRepository::class)]
class SFamililas
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column(type: 'integer')]
    private $id;

    #[ORM\Column(type: 'integer')]
    private $code;

    #[ORM\Column(type: 'string', length: 255)]
    private $nom;

    #[ORM\Column(type: 'string', length: 255, nullable: true)]
    private $userModify;

    #[ORM\Column(type: 'datetime', nullable: true)]
    private $dateModify;

    #[ORM\Column(type: 'integer', nullable: true)]
    private $active;

    #[ORM\OneToMany(mappedBy: 'family', targetEntity: SGroup::class)]
    private $sGroups;

    #[ORM\OneToMany(mappedBy: 'family', targetEntity: SArticle::class)]
    private $sArticles;

    public function __construct()
    {
        $this->sGroups = new ArrayCollection();
        $this->sArticles = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getCode(): ?int
    {
        return $this->code;
    }

    public function setCode(int $code): self
    {
        $this->code = $code;

        return $this;
    }

    public function getNom(): ?string
    {
        return $this->nom;
    }

    public function setNom(string $nom): self
    {
        $this->nom = $nom;

        return $this;
    }

    public function getUserModify(): ?string
    {
        return $this->userModify;
    }

    public function setUserModify(?string $userModify): self
    {
        $this->userModify = $userModify;

        return $this;
    }

    public function getDateModify(): ?\DateTimeInterface
    {
        return $this->dateModify;
    }

    public function setDateModify(?\DateTimeInterface $dateModify): self
    {
        $this->dateModify = $dateModify;

        return $this;
    }

    public function getActive(): ?int
    {
        return $this->active;
    }

    public function setActive(?int $active): self
    {
        $this->active = $active;

        return $this;
    }

    /**
     * @return Collection|SGroup[]
     */
    public function getSGroups(): Collection
    {
        return $this->sGroups;
    }

    public function addSGroup(SGroup $sGroup): self
    {
        if (!$this->sGroups->contains($sGroup)) {
            $this->sGroups[] = $sGroup;
            $sGroup->setFamily($this);
        }

        return $this;
    }

    public function removeSGroup(SGroup $sGroup): self
    {
        if ($this->sGroups->removeElement($sGroup)) {
            // set the owning side to null (unless already changed)
            if ($sGroup->getFamily() === $this) {
                $sGroup->setFamily(null);
            }
        }

        return $this;
    }

    /**
     * @return Collection|SArticle[]
     */
    public function getSArticles(): Collection
    {
        return $this->sArticles;
    }

    public function addSArticle(SArticle $sArticle): self
    {
        if (!$this->sArticles->contains($sArticle)) {
            $this->sArticles[] = $sArticle;
            $sArticle->setFamily($this);
        }

        return $this;
    }

    public function removeSArticle(SArticle $sArticle): self
    {
        if ($this->sArticles->removeElement($sArticle)) {
            // set the owning side to null (unless already changed)
            if ($sArticle->getFamily() === $this) {
                $sArticle->setFamily(null);
            }
        }

        return $this;
    }
}
