<?php

namespace App\Entity;

use App\Repository\SArticleRepository;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: SArticleRepository::class)]
class SArticle
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column(type: 'integer')]
    private $id;

    #[ORM\ManyToOne(targetEntity: sfamililas::class, inversedBy: 'sArticles')]
    private $family;

    #[ORM\ManyToOne(targetEntity: sgroup::class, inversedBy: 'sArticles')]
    private $grouper;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getFamily(): ?sfamililas
    {
        return $this->family;
    }

    public function setFamily(?sfamililas $family): self
    {
        $this->family = $family;

        return $this;
    }

    public function getGrouper(): ?sgroup
    {
        return $this->grouper;
    }

    public function setGrouper(?sgroup $grouper): self
    {
        $this->grouper = $grouper;

        return $this;
    }
}
