<?php

namespace App\Repository;

use App\Entity\SGroup;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @method SGroup|null find($id, $lockMode = null, $lockVersion = null)
 * @method SGroup|null findOneBy(array $criteria, array $orderBy = null)
 * @method SGroup[]    findAll()
 * @method SGroup[]    findBy(array $criteria, array $orderBy = null, $limit = null, $offset = null)
 */
class SGroupRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, SGroup::class);
    }

    // /**
    //  * @return SGroup[] Returns an array of SGroup objects
    //  */
    /*
    public function findByExampleField($value)
    {
        return $this->createQueryBuilder('s')
            ->andWhere('s.exampleField = :val')
            ->setParameter('val', $value)
            ->orderBy('s.id', 'ASC')
            ->setMaxResults(10)
            ->getQuery()
            ->getResult()
        ;
    }
    */

    /*
    public function findOneBySomeField($value): ?SGroup
    {
        return $this->createQueryBuilder('s')
            ->andWhere('s.exampleField = :val')
            ->setParameter('val', $value)
            ->getQuery()
            ->getOneOrNullResult()
        ;
    }
    */
}
